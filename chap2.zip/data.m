
clear; clc
rs_ind = 0.0453;
rr_ind = 0.0222;
H_ind = 0.5;
XM_ind = 2.042;
Xls_ind = 0.0775;
%Xls_ind = 2.0775;
Xlr_ind = 0.0322;

wm =0;

k_s = 1.0;
we =2*pi*60;
%we =1;
Xss_ind = Xls_ind + XM_ind;
Xrr_ind = Xlr_ind + XM_ind;
% Step 1: Free Acceleration: Assume that Va Vb Vc are symmetric voltages..
%Tm= Te_fun(I0, XM);
I0_ind=zeros(6,1);
TL_ind = 1.0;
%H_ind = 0.5;
L_ind=1/we*[Xss_ind, 0, 0, XM_ind, 0, 0;
    0, Xss_ind, 0, 0, XM_ind, 0;
    0, 0, Xls_ind, 0, 0, 0;
    XM_ind, 0, 0, Xrr_ind, 0, 0;
    0, XM_ind, 0, 0, Xrr_ind, 0;
    0, 0, 0, 0, 0, Xlr_ind];

Bb_ind = inv(L_ind);

Vas_ind = 1;

slip_old = 1-wm;


