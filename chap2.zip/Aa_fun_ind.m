function out = Aa_fun_ind(u,rs, Xss, XM, rr, Xrr, Xls,Xlr)

wr = u(1);
we = 2*pi*60;
R=[rs, Xss, 0, 0, XM, 0;
   -Xss, rs, 0, -XM, 0, 0;
   0, 0, rs, 0, 0, 0;
   0, (1-wr)*XM, 0, rr, (1-wr)*Xrr, 0;
   -(1-wr)*XM, 0, 0, -(1-wr)*Xrr, rr, 0;
   0, 0, 0, 0, 0, rr];

L=1/we*[Xss, 0, 0, XM, 0, 0;
    0, Xss, 0, 0, XM, 0;
    0, 0, Xls, 0, 0, 0;
    XM, 0, 0, Xrr, 0, 0;
    0, XM, 0, 0, Xrr, 0;
    0, 0, 0, 0, 0, Xlr];

Aa=-inv(L)*R;
     
out = Aa*u(2:7);
 