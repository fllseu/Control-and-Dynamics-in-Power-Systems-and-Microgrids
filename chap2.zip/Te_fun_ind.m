function out = Te_fun_ind(u, XM)

iqs = u(1);
ids = u(2);
i0s = u(3);
iqr = u(4);
idr = u(5);
i0r = u(6);
    
out = XM*(iqs*idr-ids*iqr);
